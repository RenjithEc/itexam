<!doctype html>
<html>
<head>
<meta charset="utf-8">
    <meta name="viewport" content="">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="creater" content="">
    <title>BR ENTERPRISES | Welcome</title>
    <link rel="stylesheet" href="./css/search.css">
</head>


<body>
<header>
     <div class="container">
       <div id="branding">
         <h1><a href="index1.php"><span class="highlight">BR ENTERPRISES</span></a></h1>
       </div>
       <nav>
         <ul>
          
<li><a href="logout.php">logout</a></li>
         </ul>
       </nav>
     </div>
   </header>
<div class=container1>
<form action="" method="post">

<input type="text" name="pro" placeholder="Search by Product" autocomplete="off">
<input type="value" name="dim" placeholder="Dimensioin" autocomplete="off">
<input type="value" name="min" placeholder="enter min price">
<input type="value" name="max" placeholder="enter max price">
<input type="submit" value="search"></br>

</form>
</div>

<?php
$m=mysqli_connect("localhost","root","12345","project") or die("ERROR");
if ($_POST["pro"]!=NULL){
$pro=$_POST["pro"];
$dim=$_POST["dim"];
$min=$_POST["min"];
$max=$_POST["max"];

$q="select * from product where Pname='$pro' or dim='$dim' or price BETWEEN '$min' and '$max'";
$sum=mysqli_query($m,$q);
$res=mysqli_query($m,$q);
$p=mysqli_fetch_array($sum);
echo "<p><h3>Product: ".$p['Pname']."</h3></p>";
while ($r=mysqli_fetch_assoc($res))
{
echo '<a href="'.$r['Pname'].'.php">'.$r['Pname'].'</a></br>';
}
}
?>
</div>
 <footer>
     <p>BR ENTERPRISES,&copy 2018</p>
   </footer>
</body>
</html>
