<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="creater" content="">
    <title>BR ENTERPRISES | Welcome</title>
    <link rel="stylesheet" href="./css/style.css">
  </head>
  <body>
   <header>
     <div class="container">
       <div id="branding">
         <h1><a href="index1.php"><span class="highlight">BR ENTERPRISES</span></a></h1>
       </div>
       <nav>
         <ul>
           <li><a href="index1.php">Home</a></li>
           <li class="current"><a href="about.php">About us</a></li>
           <li><a href="we.php">We Provide</a></li>
           <li><a href="login.php">login</a></li>
         </ul>
       </nav>
     </div>
   </header>


   <section id="newsletter">
     <div class="container">
     <h1>Get update</h1>
     <form action="1.html" method="post" target="_blank">

       <input type="email" name="Email" placeholder="Enter Email....">
       <button type="submit" class="button_1">Subscribe</button>
     </form>
     </div>
   </section>
   <section id="main">
     <div class="container">
       <article id="main-sexy">
         <h1 class="page-title">About Us</h1>
         <p>Welcome to BR ENTERPRISES for Industrial Equipment and Supplies. The buyers can easily and instantly access to the list of the industrial equipment manufacturers, Industrial Supplies. The various categories, which fall under this, are industrial services, hydraulic components, industrial dryers and so on. Sellers can list their offered industrial supplies within the appropriate product categories and can receive uncounted business enquiries from best buyers.</p>
<div class="box">
       <img src="./img/14.jpg">
</div>
<p class="dark">Welcome to BR ENTERPRISES for Industrial Equipment and Supplies. The buyers can easily and instantly access to the list of the industrial equipment manufacturers, Industrial Supplies. The various categories, which fall under this, are industrial services, hydraulic components, industrial dryers and so on. Sellers can list their offered industrial supplies within the appropriate product categories and can receive uncounted business enquiries from best buyers.</p>
       </article>

       <aside id="sidebar">
         <div class="dark">
         <h3>Contact Info:</h3>
         <p>Address:</p>
	<p>No.14,10th cross,Bagalagunte,Nagasandra Post,Bangalore-560073</p>
	<p>Tel:080-28377687</p>
	<p>Email:kccbabu@yahoo.com</p>
       </div>
       </aside>
     </div>
 </section>


   <footer>
     <p>BR ENTERPRISES,&copy 2018</p>
   </footer>
  </body>
</html>
