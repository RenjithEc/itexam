<?php
session_start();
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <meta name="description" content="Online Hotel Booking">
    <meta name="keywords" content="Cheap Hotels,Budget Hotels,Luxery Hotels">
    <meta name="creater" content="Schneizel">
    <title>Online Hotel Booking | About</title>
    <link rel="stylesheet" href="./css/style.css">
  </head>
  <body>
   <header>
     <div class="container">
       <div id="branding">
         <h1><span class="highlight">Online</span> Hotel Booking</h1>
       </div>
       <nav>
         <ul>
           <li><a href="index1.php">Home</a></li>
           <li class="current"><a href="about.php">About us</a></li>
           <li><a href="we.php">We Provide</a></li>
           <li><a href="Sign-up.php">Sign Up</a></li>
           <li><a href="login.php">login</a></li>
         </ul>
       </nav>
     </div>
   </header>


   <section id="newsletter">
     <div class="container">
     <h1>Get update</h1>
     <form action="1.php" method="post" target="_blank">

       <input type="email" name="Email" placeholder="Enter Email....">
       <button type="submit" class="button_1">Subscribe</button>
     </form>
     </div>
   </section>
   <section id="main">
     <div class="container">
       <article id="main-sexy">
         <h1 class="page-title">About Us</h1>
         <p>Sed commodo nunc et libero imperdiet condimentum. Vivamus et bibendum lectus. Maecenas aliquet mi at sollicitudin scelerisque. Donec orci enim, venenatis at viverra ac, viverra sed elit. Praesent et velit tellus. Proin aliquet ac sem id aliquet. Etiam non euismod odio, in feugiat urna. Mauris aliquet, mauris at molestie efficitur, risus nunc pretium ipsum, eu fringilla nunc augue vel sem. Praesent vulputate rutrum tortor in porttitor. Curabitur eu velit id ante commodo euismod ac eu metus. Sed eu consectetur lacus. Integer tristique dignissim volutpat. In eu pulvinar ex. In hac habitasse platea dictumst. Nullam vitae elit in elit blandit porta.</p>

<p class="dark">Aliquam a orci at nunc blandit faucibus eu at ex. Etiam nec orci tempor mauris lobortis porttitor. Donec tincidunt turpis eget mauris consequat porttitor. Phasellus commodo facilisis lacus, vitae iaculis ex mattis sit amet. Integer venenatis, quam a aliquet convallis, odio nulla ullamcorper quam, sit amet aliquet dolor turpis quis nisi. Suspendisse tristique condimentum leo. Morbi congue fringilla augue commodo luctus. Proin sodales feugiat justo, ac ullamcorper mi sodales sed.</p>
       </article>

       <aside id="sidebar">
         <div class="dark">
         <h3>What We Do</h3>
         <p>Vivamus id aliquam enim. Etiam congue convallis metus, non imperdiet justo aliquet vel. Aenean vulputate felis non nisi porta sagittis. Nunc in urna id arcu pretium finibus sed nec orci. Cras condimentum odio consectetur enim molestie, non accumsan mauris dapibus. Quisque eleifend volutpat augue sed elementum. Morbi vitae tortor magna. In eleifend sodales consequat.</p>
       </div>
       </aside>
     </div>
 </section>


   <footer>
     <p>Hotick, copyright &copy; 2017</p>
   </footer>
  </body>
</html>
