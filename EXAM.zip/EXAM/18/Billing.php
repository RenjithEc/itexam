

    <?php session_start();
    if(!isset($_SESSION['id'])){
    	echo '<script>windows: location="index.php"</script>';
    	}
    ?>
    <?php
    $session=$_SESSION['id'];
    include 'db.php';
    $result = mysql_query("SELECT * FROM user where id= '$session'");
    while($row = mysql_fetch_array($result))
      {
      $sessionname=$row['name'];
      }
    ?>
    <!DOCTYPE html>
    <html>
    <head>
    <title>Simple Water Billing System</title>
    <link href="css/bootstrap.min.css" media="screen" rel="stylesheet" type="text/css" />
    <link href="css/facebox.css" media="screen" rel="stylesheet" type="text/css" />
    <script src="js/jquery1.js" type="text/javascript"></script>
    <script src="css/facebox.js" type="text/javascript"></script>
      <script type="text/javascript">
    	jQuery(document).ready(function($) {
    	  $('a[rel*=facebox]').facebox({
    		loadingImage : 'src/loading.gif',
    		closeImage   : 'src/closelabel.png'
    	  })
    	})
      </script>
    <script src="js/application.js" type="text/javascript" charset="utf-8"></script>	
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Simple Water Billing System</title>
    </head>
    <body>
    <nav class="navbar navbar-default">
    	<div class="container-fluid">
    		<div class="navbar-header">
    			<a class="navbar-brand" href="<a href="https://www.sourcecodester.com">Sourcecodester</a>
    " rel="nofollow">https://www.sourcecodester.com">Sourcecodester</a>
    </a>		</div>
    		<ul class="nav navbar-nav">
    		<li class="active"><a href="billing.php">Home</a></li>
    		<li><a href="bill.php">Billing</a></li>
    		<li><a href="user.php">Users</a></li>
    		<li><a href="addclient.php">Add Client</a></li>
    		<li><a href="viewuser.php">View Client</a></li>
    		<li><a href="logout.php">Logout</a></li>
    		</ul>
    	</div>
    </nav>
    <h1 align="center">Simple Water Billing System</h1>
    </body>
    </html>
