<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <meta name="description" content="Online Hotel Booking">
    <meta name="keywords" content="Cheap Hotels,Budget Hotels,Luxery Hotels">
    <meta name="creater" content="Schneizel">
    <title>Online Hotel Booking | Welcome</title>
    <link rel="stylesheet" href="./css/style.css">
  </head>



  <body>

   <header>
     <div class="container">
       <div id="branding">
         <h1><span class="highlight">Online</span> Hotel Booking</h1>
       </div>
       <nav>
         <ul>
         <li><a href="logout.php">logout</a></li>
         </ul>
       </nav>
     </div>
   </header>

   <section id="boxes1">
     <div class="container3">

     <div class="box">
     <h1> Chennai </h1>
    
     <div class="box">
      <h2> Hotel Vegeta </h2>

     <img src="./img/2s5.png">
      
     <p>Price : 1900rs
     <form action="payment1.php" method="post">
       <button type="submit" class="button_1">Book Now</button>
        </form></p>
     </div>
     
     
   
     
     </div>
   </section>



   <footer>
     <p>Hotick, copyright &copy; 2017</p>
   </footer>
  </body>
</html>
