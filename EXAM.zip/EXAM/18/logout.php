<?php   
session_start();
session_unset();
//unset($_SESSION['sess_user']);
session_destroy();
header("location: login.php");
exit()
?>
