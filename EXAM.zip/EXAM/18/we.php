<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <meta name="description" content="Online Hotel Booking">
    <meta name="keywords" content="Cheap Hotels,Budget Hotels,Luxery Hotels">
    <meta name="creater" content="Schneizel">
    <title>Online Hotel Booking | We Provide</title>
    <link rel="stylesheet" href="./css/style.css">
  </head>
  <body>
   <header>
     <div class="container">
       <div id="branding">
         <h1><span class="highlight">Online</span> Hotel Booking</h1>
       </div>
       <nav>
         <ul>
           <li><a href="index1.php">Home</a></li>
           <li><a href="about.php">About us</a></li>
           <li class="current"><a href="#">We Provide</a></li>
           <li><a href="Sign-up.php">Sign Up</a></li>
           <li><a href="login.php">login</a></li>
         </ul>
       </nav>
     </div>
   </header>


   <section id="newsletter">
     <div class="container">
     <h1>Get Update</h1>
     <form action="1.html" method="post" target="_blank">

       <input type="email" name="Email" placeholder="Enter Email....">
       <button type="submit" class="button_1">Subscribe</button>
     </form>
     </div>
   </section>
   <section id="main">
     <div class="container">
       <article id="main-sexy">
         <h1 class="page-title">Coupons and offers</h1>
         <ul id="services">
           <li>
             <h3>Rate Us</h3>
             <img src="./img/123.png" style="width:270px;height:270px;"	>
               <p>Scan and be with us.</p>
           </li>
          
           <li>
             <h3>Offered Coupons</h3>
             <img src="./img/1234.png" style="width:270px;height:270px;"	>
               <p>Available Coupons.</p>
           </li>
         </ul>

       </article>


 </section>


   <footer>
     <p>Hotick, copyright &copy; 2017</p>
   </footer>
  </body>
</html>
