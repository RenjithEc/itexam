<?php
session_start();
?>
<!doctype html>
<html>
<head>
 <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <meta name="description" content="Online Hotel Booking">
    <meta name="keywords" content="Cheap Hotels,Budget Hotels,Luxery Hotels">
    <meta name="creater" content="Schneizel">
    <title>Online Hotel Booking | Welcome</title>
    <link rel="stylesheet" href="./css/style.css">
</head>

<script type="text/javascript">
	function val()
	{
	if(frm.credit.value=="")
	{
		alert("Please enter the card number");
		frm.credit.focus();
		return false;
	}
	if(isNaN(frm.credit.value))
	{
		alert("Invaild card number");
		frm.credit.focus();
		return false;
	}
	if((frm.credit.value).length<16)
	{
		alert("Card number should be 16 digits");
		frm.credit.focus();
		return false;
	}
	return true;
	}
</script>


<!-- <script type="text/javascript">
	function value()
	{
	if(frm.Deb.value=="")
	{
		alert("Please enter the card number");
		frm.Deb.focus();
		return false;
	}
	if(isNaN(frm.Deb.value))
	{
		alert("Invaild card number");
		frm.Deb.focus();
		return false;
	}
	if((frm.Deb.value).length<16)
	{
		alert("Card number should be minimum 16 digits");
		frm.Deb.focus();
		return false;
	}
	return true;
	}


</script> -->

<body>

   <header>
     <div class="container">
       <div id="branding">
         <h1><span class="highlight">Online</span> Hotel Booking</h1>
       </div>
       <nav>
         <ul>
           <li class="current"><a href="#">Home</a></li>
           <li><a href="about.php">About us</a></li>
           <li><a href="we.php">We Provide</a></li>
           <li><a href="Sign-up.php">Sign Up</a></li>
           <li><a href="login.php">login</a></li>
         </ul>
       </nav>
     </div>
   </header>

<h1> <center>Make payment</center> </h1>


<div id="CreditCard" class="content">
		<h3>Credit Card</h3>
		<form name="frm" method="post" action="confirm.php">
		Card Number:<br/> <input type="text" name="credit" placeholder="Enter Card Number" autocomplete="off" required="credit" /><br/>
		Card Holder Name:<br/> <input type="text" name="cname" placeholder="Enter card Holder Name" autocomplete="off" /><br/>
		<input type="submit" value="Proceed" name="submit">
		</form>


</div>

<!---
<div id="DebitCard" class="content">
		<h3>Debit Card</h3>
		<form name="frm" method="post" action="thankyou.html">
		Card Number:<br/> <input type="text" name="debit" placeholder="Enter Card Number" autocomplete="off" required="Deb" /><br/>
		Card Holder Name:<br/> <input type="text" name="dname" placeholder="Enter card Holder Name" autocomplete="off" ><br/>

<input type="submit" value="Proceed" name="submit">
		</form>
--->
<script>
function payment(evt, option)
{
	var i,link, content;
	content=document.getElementsByClassName("content");
	for(i=0;i<content.length;i++)
		{
			content[i].style.display="none";
		}
	link = document.getElementsByClassName("link");
    for (i = 0; i < link.length; i++) {
        link[i].className = link[i].className.replace(" active", "");
    }
    document.getElementById(option).style.display = "block";
    evt.currentTarget.className += " active";
}
document.getElementById("defaultOpen").click();
</script>
<section id="boxes">
	<div class="container">

	<div class="box">
	<h1> Payment Through Paytm </h1>
	<p>Scan the QR-Code.</p>
   <img src="./img/12345.png" style="width:270px;height:270px;"	>

</div>
</div>
</section>
<?php
if(isset($_POST["submit"])){
 if(!empty($_POST['credit']) && !empty($_POST['cname']))
{
$credit = $_POST['credit'];
$cname = $_POST['cname'];
//$debit = $_POST['debit'];
//$dname = $_POST['dname'];
$conn = new mysqli('localhost', 'root', 'Kevin123') or die (mysqli_error()); // DB Connection
$db = mysqli_select_db($conn, 'project') or die("DB Error"); // Select DB from database
//Selecting Database
$numrows == 0;
if($numrows == 0)
{
//Insert to Mysqli Query
$sql1="INSERT INTO credit(credit,cname) VALUES ('$credit','$cname')";
//$sql1="INSERT INTO debit(debit,dname)VALUES('$debit','$dname')";
$r1 = mysqli_query($conn, $sql1);
//$r2 = mysqli_query($conn, $sql1);
//Result Message
if($r1){
echo "Your Account Created Successfully";
}
else
{
echo "Failure!";
}
}
else
{
echo "That Username already exists! Please try again.";
}
}
}
?>
<footer>
	<p>Hotick, copyright &copy; 2017</p>
  </footer>	

</body>

</html>
