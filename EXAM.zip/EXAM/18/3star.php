<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <meta name="description" content="Online Hotel Booking">
    <meta name="keywords" content="Cheap Hotels,Budget Hotels,Luxery Hotels">
    <meta name="creater" content="Schneizel">
    <title>Online Hotel Booking | Welcome</title>
    <link rel="stylesheet" href="./css/style.css">
  </head>



  <body>

   <header>
     <div class="container">
       <div id="branding">
         <h1><span class="highlight">Online</span> Hotel Booking</h1>
       </div>
       <nav>
         <ul>
           <li class="current"><a href="#">Home</a></li>
           <li><a href="about.php">About us</a></li>
           <li><a href="we.php">We Provide</a></li>
           <li><a href="Sign-up.php">Sign Up</a></li>
           <li><a href="login.php">login</a></li>
         </ul>
       </nav>
     </div>
   </header>

   <section id="boxes">
     <div class="container">

     <div class="box">

       <img src="./img/3s2.png">
      <h3>Hotel Avisha,Kolkata</h3>
     <p>Price : 1232rs
     <form action="login1.php" method="post">
       <button type="submit" class="button_1">Book Now</button>
        </form></p>
     </div>


      <div class="box">
       <img src="./img/3s0.png">
      <h3>Hotel Kalyan,Jaipur</h3>
     <p>Price : 1159rs
     <form action="login1.php" method="post">
       <button type="submit" class="button_1">Book Now</button>
        </form></p>
     </div>


      <div class="box">
       <img src="./img/3s2.png">
      <h3>Hotel Meru,Pune</h3>
     <p>Price : 1344rs
     <form action="login1.php" method="post">
       <button type="submit" class="button_1">Book Now</button>
        </form></p>
      </div>


      <div class="box">
        <img src="./img/3s3.png">
       <h3>Hotel Bhooshan,Pune</h3>
      <p>Price : 2124rs
      <form action="login1.php" method="post">
        <button type="submit" class="button_1">Book Now</button>
         </form></p>
      </div>






       <div class="box">
        <img src="./img/3s4.png">
       <h3>Hotel Midland,Mumbai</h3>
      <p>Price : 3562rs
      <form action="login1.php" method="post">
        <button type="submit" class="button_1">Book Now</button>
         </form></p>
       </div>


       <div class="box">
         <img src="./img/3s5.png">
        <h3>Hotel Chanchal Continental,Delhi</h3>
       <p>Price : 1684rs
       <form action="login1.php" method="post">
         <button type="submit" class="button_1">Book Now</button>
          </form></p>
       </div>


        <div class="box">
         <img src="./img/3s6.png">
        <h3>Roland Hotel,Kolkata</h3>
       <p>Price : 2645rs
       <form action="login1.php" method="post">
         <button type="submit" class="button_1">Book Now</button>
          </form></p>
       </div>

     </div>
   </section>



   <footer>
     <p>Hotick, copyright &copy; 2017</p>
   </footer>
  </body>
</html>
s
