

    <?php session_start();
    if(!isset($_SESSION['id'])){
    	echo '<script>windows: location="index.php"</script>';
     
    	}
    ?>
    <?php
    include 'db.php';
    $id =$_REQUEST['id'];
    $result = mysql_query("SELECT * FROM bill where id='$id'");
    while($row = mysql_fetch_array($result))
      {
    	  $prev=$row['prev'];
    	  $owners_id=$row['owners_id'];
    	  $pres=$row['pres'];
    	  $price=$row['price'];
    	  $totalcons=$pres - $prev;
    	  $bill=$totalcons * $price;
    	  $date=$row['date'];
     
      }
    ?>
    <?php
    include 'db.php';
    $result = mysql_query("SELECT * FROM owners WHERE id  = '$owners_id'");
    $test = mysql_fetch_array($result);
    if (!$result) 
    		{
    		die("Error: Data not found..");
    		}
    				$id=$test['id'] ;
    				$fname= $test['fname'] ;					
    				$lname=$test['lname'] ;
    				$mi=$test['mi'] ;
    				$address=$test['address'] ;
    				$contact=$test['contact'] ;
     
    ?>
    <?php
    $session=$_SESSION['id'];
    include 'db.php';
    $result = mysql_query("SELECT * FROM user where id= '$session'");
    while($row = mysql_fetch_array($result))
      {
      $sessionname=$row['name'];
      }
    ?>
