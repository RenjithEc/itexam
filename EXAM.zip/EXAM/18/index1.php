<?php
session_start();
?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <meta name="description" content="Online Hotel Booking">
    <meta name="keywords" content="Cheap Hotels,Budget Hotels,Luxery Hotels">
    <meta name="creater" content="Schneizel">
    <title>Online Hotel Booking | Welcome</title>
    <link rel="stylesheet" href="./css/style.css">
  </head>



  <body>


   <header>
     <div class="container">
       <div id="branding">
         <h1><span class="highlight">Online</span> Hotel Booking</h1>
       </div>
       <nav>
         <ul>
           <li class="current"><a href="#">Home</a></li>
           <li><a href="about.php">About us</a></li>
           <li><a href="we.php">We Provide</a></li>
           <li><a href="Sign-up.php">Sign Up</a></li>
           <li><a href="login.php">login</a></li>
         </ul>
       </nav>
     </div>
   </header>


   <section id="showcase">
     <div class="container">
      <h1>Best Place for book your Tickets</h1>
      <p>Hotick is an online travel organization founded in January 2017 by Schneizel.</p>
     </div>
   </section>


   <section id="newsletter">
     <div class="container">
     <h1>Get update</h1>
     <form action="1.html" method="post" target="_blank">

       <input type="email" name="Email" placeholder="Enter Email....">
       <button type="submit" class="button_1">Subscribe</button>
     </form>
     </div>
   </section>


   <section id="boxes">
     <div class="container">
     <div class="box">
       <img src="./img/logo_cheap1.png">
      <h3>2Stars Hotels</h3>
      <form action="2star.php" method="post">
     <button type="submit" class="button_1">Preview</button>
       </form>
     <p>Small, friendly, family-run and well-kept in every way, the Casa Boccassini Hotel stands out among one star hotels in Venice for its warm atmosphere and for the quality of the amenities and services it offers.</p>
     </div>
      <div class="box">
       <img src="./img/logo_budget.png">
      <h3>3Stars  Hotels</h3>
      <form action="3star.php" method="post">
     <button type="submit" class="button_1">Preview</button>
       </form>
     <p>Budget hotel is the category of hotel that provides the rooms and meals at cheap cost. Budget hotel offers the facilities which required to fulfilling basic requirements.</p>
     </div>
      <div class="box">
       <img src="./img/luxery.png">
      <h3>5Stars Hotels</h3>
        <form action="5star.php" method="post">
       <button type="submit" class="button_1">Preview</button>
         </form>
     <p>A Luxury Hotel is considered a hotel which provides a luxurious accommodation experience to the guest. There are no set standards (such as stars) for luxury hotels. Often 4 or 5 star hotels describe themselves as ‘luxury’.</p>
      </div>
     </div>
 </section>


   <footer>
     <p>Hotick, copyright &copy; 2017</p>
   </footer>
  </body>
</html>
