-- MySQL dump 10.13  Distrib 5.7.20, for Linux (x86_64)
--
-- Host: localhost    Database: project
-- ------------------------------------------------------
-- Server version	5.7.20-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin` (
  `email` varchar(20) NOT NULL,
  `pass` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` VALUES ('kevinroy@gmail.com','Kevin123'),('rakdota@gmail.com','wasddota');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hotel1`
--

DROP TABLE IF EXISTS `hotel1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hotel1` (
  `Cid` varchar(50) NOT NULL,
  `hotel` varchar(20) DEFAULT NULL,
  `room` int(10) DEFAULT NULL,
  `city` varchar(20) DEFAULT NULL,
  `price` varchar(50) NOT NULL,
  PRIMARY KEY (`Cid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hotel1`
--

LOCK TABLES `hotel1` WRITE;
/*!40000 ALTER TABLE `hotel1` DISABLE KEYS */;
INSERT INTO `hotel1` VALUES ('1','ITC Gardenia',2,'Bangalore','4333'),('10','Taj Vivanta',1,'Bangalore','1235'),('11','Hotel Flash',2,'Bangalore ','2314'),('12','Hotel Jack',1,'Delhi','3729'),('13','Hotel Rambo',2,'Delhi','7733'),('14','Hotel Sanji',1,'Kolkata','7432'),('15','Hotel Taj',2,'Chennai','6326'),('16','Hotel Lambo',2,'Chennai','7326'),('17','Hotel Ferrari',2,'Kolkata','1234'),('18 ','Hotel Ford',1,'Kolkata','5437'),('19','Hotel GM',3,'Kolkata','3251'),('2','Hotel Zoro',1,'Delhi','3562'),('20','Hotel Tata',2,'Kolkata','2345'),('21','Hotel Gohan',1,'Mumbai','4231'),('22','Hotel Nami',2,'Mumbai','5421'),('23','Hotel Robin',3,'Mumbai','5332'),('24','Hotel Wonderwomen',1,'Mumbai','2352'),('25','Hotel Zara',2,'Mumbai','5323'),('3','Le Merdian',1,'Bangalore','3537'),('4','Hotel Batman',1,'Chennai','2536'),('5','Hotel Superman',2,'Delhi','2473'),('6','Hotel Luffy',3,'Bangalore','7323'),('7','Hotel Keys',1,'Chennai','7252'),('8','Hotel Goku',2,'Delhi','3735'),('9','Hotel Vegeta',3,'Chennai','7362');
/*!40000 ALTER TABLE `hotel1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pro1`
--

DROP TABLE IF EXISTS `pro1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pro1` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Fname` varchar(50) DEFAULT NULL,
  `Lname` varchar(50) DEFAULT NULL,
  `user` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `pass` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=912 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pro1`
--

LOCK TABLES `pro1` WRITE;
/*!40000 ALTER TABLE `pro1` DISABLE KEYS */;
INSERT INTO `pro1` VALUES (911,'kevin','roy','kevin','kevin@gmail.com','Kevin123');
/*!40000 ALTER TABLE `pro1` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-12-09  9:33:01
