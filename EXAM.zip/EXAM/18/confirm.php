<!doctype html>
<html>
<head>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <meta name="description" content="Online Hotel Booking">
    <meta name="keywords" content="Cheap Hotels,Budget Hotels,Luxery Hotels">
    <meta name="creater" content="Schneizel">
    <title>Online Hotel Booking | Welcome</title>
    <link rel="stylesheet" href="./css/style3.css">
</head>
 <body>
 <header>
     <div class="container">
       <div id="branding">
         <h1><span class="highlight">Online</span> Hotel Booking</h1>
       </div>
       <nav>
         <ul>
           <li><a href="index1.php">Home</a></li>
           <li><a href="about.php">About us</a></li>
           <li><a href="we.php">We Provide</a></li>
           <li><a href="Sign-up.php">Sign Up</a></li>
	 <li class="current"><a href="#">Login</a></li>
         </ul>
       </nav>
     </div>
   </header>

<form action="index1.php">
<h1>Thank you!!! Your booking has been confirmed....!<br>
 Eagerly waiting for your arrival</h1>
<section id="boxes">
	<div class="container">

	<div class="box">
<center><h2> Like US? Tell Us. </h2></center>
 <center>  <img src="./img/123.png" style="width:200px;height:200px;"></center>
<input type="submit" value="Home page" /> 
</form>
  </body>
</html>
