<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="creater" content="">
    <title>BR ENTERPRISES | Welcome</title>
    <link rel="stylesheet" href="./css/style.css">
  </head>
  <body>
   <header>
     <div class="container">
       <div id="branding">
        <h1><a href="index1.php"><span class="highlight">BR ENTERPRISES</span></a></h1>
       </div>
       <nav>
         <ul>
    <li><a href="logout.php">logout</a></li>
         </ul>
       </nav>
     </div>
   </header>

   <section id="boxes1">
     <div class="container3">

     <div class="box">
     <h1> PRODUCT NAME </h1>
    
     <div class="box">
      <h2>Buffing Wheel</h2>

     <img src="./img/4.jpg">
      
     <p>Price : Rs 400
     </div>
     
     
   
     
     </div>
   </section>



   <footer>
     <p>BR ENTERPRISES,&copy 2018</p>
   </footer>
  </body>
</html>
