
<?php
session_start();
$db_host="localhost";
$db_user="root";
$db_password="tiger";
$db_name="kev";
$name=$_POST['name'];
$id=$_POST['id'];
$section=$_POST['section'];
$cgpa=$_POST['cgpa'];


		
$con=mysqli_connect($db_host,$db_user,$db_password,$db_name) or die("Error querying database");
$query="insert into can values('$id','$name','$section','0','$cgpa');";
$result=mysqli_query($con,$query) or die("Error queryong database");

echo "you've registered<br />";

?>

