<!DOCTYPE html>
<html>
<head>


</head>
<body>

<h2> Search for Winner</h2>
<form  method="post">
<label>Section:</label><input type="text" name="section" required><br/>

<input type="submit" value="search" name="submit"><br/>

</form>

<?php
if(isset($_POST["submit"])){
 if(!empty($_POST['section']) ){
 $sec = $_POST['section'];
 //DB Connection
 $conn = new mysqli('localhost', 'root', 'tiger') or die(mysqli_error());
 //Select DB From database
 $db = mysqli_select_db($conn, 'vote') or die("databse error");
  
$query = mysqli_query($conn, "SELECT MAX(vote_count) FROM can WHERE section ='".$sec."'");

 $numrows = mysqli_num_rows($query);
 if($numrows !=0)
{
while($row = mysqli_fetch_assoc($query))
 {
 $win=$row ['MAX(vote)'];


 }}
$que = mysqli_query($conn, "SELECT name FROM can WHERE vote ='".$win."'AND section='".$sec."'");

$numrows = mysqli_num_rows($que);
 if($numrows !=0)
{
while($row = mysqli_fetch_assoc($que))
 {
 $name=$row ['name'];
echo "winner is $name";
echo " with $win votes";
 }}

 }
}
?>
</body>
</html>
