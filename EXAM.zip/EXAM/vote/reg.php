<?php>
<html>
<head>
<style>
.button {
    background-color: #4CAF50;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
}
</style>
<title>Register your self</title>
</head>
<header>
<h1><center> REGISTERATION FOR CANDIDATES</center></h1>
</header>
<body style="background-color:powderblue;">
<form method="POST" action="register.php">
<br>
<center>Username:<input type="text" name="name" required><center>
<br>
<center>Id:<input type="text" name="id" required><center>
<br>

<center>Section:<input type="text" name="section" required><center>
<br>

<center>CGPA:<input type="text" name="cgpa" required><center>
<br>

<center><input type="submit" value="Submit"class="button"><center>
<br>

</form>
</body>
</html>
<?>


