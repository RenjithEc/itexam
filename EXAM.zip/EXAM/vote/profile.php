<?php
session_start();
$db_host="localhost";
$db_user="root";
$db_password="tiger";
$db_name="kev";

$name=$_POST['name'];
$pw=$_POST['password'];
$_SESSION['id']=$name;

		
$con=mysqli_connect($db_host,$db_user,$db_password,$db_name) or die("Error querying database");
$query="select * from login where name='$name' and pass='$pw'";
$result=mysqli_query($con,$query) or die("Error queryong database");
$row=mysqli_fetch_array($result);
if($row['pass']==$pw && $row['user']==1)
{
	header('location:admin1.php');
}

elseif($row['pass']==$pw)
{
if($row['voted']==1)
{
echo "you've voted<br />";

echo "<a href='log.html'>logout";

}
else
{
$_SESSION['sec']=$row['section'];
header('location:vote2.html');
}
}
else
{
echo "Error, invalid password<br />";
echo "<a href='login.php'>GO BACK";
}
?>

