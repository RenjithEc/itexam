<?php
session_start();
$db_host="localhost";
$db_user="root";
$db_password="tiger";
$db_name="kev";
$sec=$_SESSION['sec'];
$con=mysqli_connect($db_host,$db_user,$db_password,$db_name) or die("Error querying database");
$query="select * from can where section=\"$sec\" and cgpa>=6.5";
$res=mysqli_query($con,$query) or die("error querying database");
echo '<form id="myform">';
while($view=mysqli_fetch_array($res,MYSQLI_ASSOC))
{
echo '<input type="radio" id="name1" name="candidate" value="'.$view['name'].'">'. $view['name'].'</input><br />';
}
echo '</form>';
?>
