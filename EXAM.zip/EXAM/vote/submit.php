<?php
	session_start();
	$db_host="localhost";
	$db_user="root";
	$db_pass="tiger";
	$db_name="kev";
	$names=$_SESSION['id'];
	$nam=$_GET['va'];
	$dbh=mysqli_connect($db_host,$db_user,$db_pass,$db_name) or die("Error connecting to Databsase");
	$query1="update can set count=count+1 where name=\"$nam\"";
	mysqli_query($dbh,$query1);

	$query2="update login set voted=1 where name=\"$names\"";
	mysqli_query($dbh,$query2);
?>

