			<?php
	session_start();
	$db_host="localhost";
	$db_user="root";
	$db_pass="tiger";
	$db_name="kev";
	
	$dbh=mysqli_connect($db_host,$db_user,$db_pass,$db_name) or die("Error connecting to Databsase");
	$query="select count(id) from can";
	$query1="delete from can where cgpa<6.5;";
	$result1=mysqli_query($dbh,$query1);
	echo"Validated candidates";
header('location:admin1.php');	
?>
