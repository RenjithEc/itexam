<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="creater" content="">
    <title>BR ENTERPRISES | Welcome</title>
    <link rel="stylesheet" href="./css/style1.css">
  </head>



  <body>


   <header>
     <div class="container">
       <div id="branding">
         <h1><a href="index1.php"><span class="highlight">BR ENTERPRISES</span></a></h1>
       </div>
       <nav>
         <ul>
           <li><a href="index1.php">Home</a></li>
           <li><a href="about.php">About us</a></li>
           <li><a href="we.php">We Provide</a></li>
	 <li class="current"><a href="#">Login</a></li>
         </ul>
       </nav>
     </div>
   </header>

	 <div class="container1">

	 				<h2>Log in Here</h2>
	 			<form method="post">
	 				<p>Email</p>
	 				<input type="text" placeholder=" Email" name="email" required>

	 				<p>Password</p>
	 				<input type="Password" placeholder="Password" name="pass" required>
	 				<input type="submit" name="submit" value="submit">
	 			</form>
	 		</div>
<?php
if(isset($_POST["submit"]))
{
 if(!empty($_POST['email']) && !empty($_POST['pass'])){
 $email = $_POST['email'];
 $pass = $_POST['pass'];
 //DB Connection
 $conn = new mysqli('localhost', 'root', '12345') or die(mysqli_error());
 //Select DB From database
 $db = mysqli_select_db($conn, 'project') or die("database error");
 //Selecting database
 $query = mysqli_query($conn, "SELECT * FROM sign WHERE email='".$email."' AND pass='".$pass."'") or die("table");
 $numrows = mysqli_num_rows($query);
 if($numrows !=0)
 {
 while($row = mysqli_fetch_assoc($query))
 {
 $email=$row['email'];
 
 $pass=$row['pass'];
 echo "<br/>".$email."<br/>".$pass."<br/>";
 }
if($email=="k@gmail.com")
{header("Location:create.php");
} 
elseif($email == $email && $pass == $pass)
 {
 session_start();
 $_SESSION['sess_email']=$email;
 //Redirect Browser
 header("Location:search.php");
 }
 }
 else
 {echo '<script language="javascript">';
 echo 'alert("Invalid emailname or Password!")';
echo '</script>';
 }
 }
 else
 {
 echo "Required All fields!";
 }
}
?>


   <footer>
     <p>BR ENTERPRISES,&copy 2018</p>
   </footer>

  </body>
</html>
