<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="creater" content="">
    <title>BR ENTERPRISES | Welcome</title>
    <link rel="stylesheet" href="./css/style.css">
  </head>
  <body>
   <header>
     <div class="container">
       <div id="branding">
         <h1><a href="index1.php"><span class="highlight">BR ENTERPRISES</span></a></h1>
       </div>
       <nav>
         <ul>
           <li><a href="index1.php">Home</a></li>
           <li><a href="about.php">About us</a></li>
           <li class="current"><a href="#">We Provide</a></li>
           <li><a href="login.php">login</a></li>
         </ul>
       </nav>
     </div>
   </header>


   <section id="newsletter">
     <div class="container">
     <h1>Get Update</h1>
     <form action="1.html" method="post" target="_blank">

       <input type="email" name="Email" placeholder="Enter Email....">
       <button type="submit" class="button_1">Subscribe</button>
     </form>
     </div>
   </section>
   <section id="main">
     <div class="container">
       <article id="main-sexy">
         <h1 class="page-title">Few Products</h1>
         <ul id="services">
           <li>
             <h3>Matt Wheel</h3>
             <img src="./img/2.jpg" style="width:270px;height:270px;">
		<p>Product by: Amazon Brush Co</p>
           </li>
          
           <li>
             <h3>Pickling paste</h3>
             <img src="./img/1.jpg" style="width:270px;height:270px;">
               <p>Product by: K-2 </p>
           </li>
           <li>
             <h3>Self Adhesive Tape</h3>
             <img src="./img/3.jpg" style="width:270px;height:270px;">
               <p>Product by: TIWondar </p>
           </li>
         </ul>

       </article>


 </section>


   <footer>
     <p>BR ENTERPRISES,&copy 2018</p>
   </footer>
  </body>
</html>
